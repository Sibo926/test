#!/bin/bash

# Step 1: Update package lists for upgrades and new package installations
echo "Updating package lists..."
echo Y | sudo apt update

# Step 2: Install required software
echo "Installing prerequisite software..."
echo Y | sudo apt install apt-transport-https ca-certificates curl software-properties-common

# Step 3: Add Docker's official GPG key
echo "Adding Docker's official GPG key..."
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo apt-key add -

# Step 4: Set up the Docker repository
echo "Setting up the Docker repository..."
echo Y | sudo add-apt-repository "deb [arch=amd64] https://download.docker.com/linux/ubuntu focal stable"

# Step 5: Install Docker
echo "Installing Docker..."
apt-cache policy docker-ce
echo Y | sudo apt install docker-ce

# Step 6: Install Docker Compose
echo "Installing Docker Compose..."
echo Y | sudo apt install docker-compose

# Step 7: Add current user to the docker group
echo "Adding current user to Docker group..."
sudo usermod -aG docker ${USER}

# Step 8: Docker login
echo "Logging into Docker..."
docker login https://docker.prohibet.com --username "listclient" --password "lclclc323232!"

# Step 9: Set up environment variable
ROOT_PATH="$(pwd)"
export ROOT_PATH="$(pwd)"

# Step 10: Set SSS_ENV_VAR to Credentials under ROOT_PATH
export SSS_ENV_VAR="${ROOT_PATH}/Credentials"

# Step 11: Add to .bashrc
cat <<EOF >>~/.bashrc
export ROOT_PATH="$(pwd)"
export SSS_ENV_VAR="${ROOT_PATH}/Credentials"
EOF
source ~/.bashrc
echo $SSS_ENV_VAR # Verify variable is set

# Step 12: Run Docker Compose
echo "Running Docker Compose..."
cd Application
docker-compose up -d

# Step 13: Access application
echo "Access the application at https://<IP_ADDRESS>:8002"

echo "Done!"
